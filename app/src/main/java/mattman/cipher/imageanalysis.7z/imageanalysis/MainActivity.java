package mattman.cipher.imageanalysis;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;

import java.io.IOException;

// OpenCV imports!

public class MainActivity extends Activity{

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int PICK_IMAGE = 2;
    static final String TAG = "OpenCV MainActivity";
    int STATE = 0;

    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {

        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS:
                {
                    Log.i(TAG, "OpenCV loaded successfully");
                } break;
                default:
                {
                    super.onManagerConnected(status);
                } break;
            }
        }
    };

    @Override
    public void onResume()
    {
        super.onResume();
        if (!OpenCVLoader.initDebug()) {
            Log.d(TAG, "Internal OpenCV library not found. Using OpenCV Manager for initialization");
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_0_0, this, mLoaderCallback);
        } else {
            Log.d(TAG, "OpenCV library found inside package. Using it!");
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }
    }

    WatershedClass watershedFunction = new WatershedClass();
    GrabCutClass grabcutFunction = new GrabCutClass();
    BinarizationClass binarizationFunction = new BinarizationClass();

    ImageView mImageView;
    SeekBar seekBar;
    static Bitmap imageOriginal;
    public int threshold;
    TextView mTextViewThreshold;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mImageView = (ImageView) findViewById(R.id.mImageView);

        mTextViewThreshold = (TextView) findViewById(R.id.mTextViewThreshold);
        mTextViewThreshold.setEnabled(false);

        seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setEnabled(false);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                threshold = progress;
                if(STATE == 1){
                    mImageView.setImageBitmap(watershedFunction.ImageSegmentation(imageOriginal, threshold));
                    mTextViewThreshold.setText(Integer.toString(threshold));
                }
                if(STATE == 3){
                    mImageView.setImageBitmap(binarizationFunction.ImageSegmentation(imageOriginal, threshold));
                    mTextViewThreshold.setText(Integer.toString(threshold));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                /*if(STATE == 1){
                    mImageView.setImageBitmap(watershedFunction.ImageSegmentation(imageOriginal, threshold));
                }*/
            }
        });

        }

    // Method for using smartphone camera app (selectable by user)
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    private void dispatchTakeFromFileIntent(){
        Intent takeFromFileIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        takeFromFileIntent.setType("image/*");
        startActivityForResult(Intent.createChooser(takeFromFileIntent, "Select Picture"), PICK_IMAGE);
    }

    private void showOriginalImage(){
        STATE = 0;
        mImageView.setImageResource(0);
        mImageView.setImageBitmap(imageOriginal);
        mTextViewThreshold.setEnabled(false);
        seekBar.setEnabled(false);
    }

    private void useWatershed(){
        mImageView.setImageBitmap(watershedFunction.ImageSegmentation(imageOriginal, threshold));
        STATE = 1;
        mTextViewThreshold.setEnabled(true);
        seekBar.setEnabled(true);

    }

    private void useGrabCut(){
        mImageView.setImageBitmap(grabcutFunction.ImageSegmentation(imageOriginal));
        STATE = 2;
        mTextViewThreshold.setEnabled(false);
        seekBar.setEnabled(false);
    }

    private void useBinarization(){
        mImageView.setImageBitmap(binarizationFunction.ImageSegmentation(imageOriginal, threshold));
        STATE = 3;
        mTextViewThreshold.setEnabled(true);
        seekBar.setEnabled(true);
    }

    // Method for getting the image made by camera from Intent
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            imageOriginal = imageBitmap;
            mImageView.setImageBitmap(imageBitmap);
        }

        // This wont work with too big images!
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK){
            Uri selectedImage = data.getData();
            Bitmap imageBitmap = null;
            try {
                imageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
            } catch (IOException e) {
                Toast.makeText(this, "Error while loading image!", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
            imageOriginal = imageBitmap;
            mImageView.setImageBitmap(imageBitmap);
        }
    }

   /* @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if(imageOriginal != null) {

                mImageView.setImageBitmap(imageOriginal);
            }
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            if(imageOriginal != null) mImageView.setImageBitmap(imageOriginal);
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        // Menu button responsible for shooting camera
        if (id == R.id.takephoto) {
            dispatchTakePictureIntent();
            return true;
        }

        if (id == R.id.photofromfile) {
            dispatchTakeFromFileIntent();
            return true;
        }

        // Menu button responsible for Segmentation
        if (id == R.id.watershed){
            useWatershed();
            return true;
        }

        if (id == R.id.grabcut){
            useGrabCut();
            return true;
        }

        if (id == R.id.binarization){
            useBinarization();
            return true;
        }

        if (id == R.id.originalimage){
            Log.i(TAG, "ShowImage");
            showOriginalImage();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPrepareOptionsMenu (Menu menu) {
        if (imageOriginal!=null) menu.getItem(2).setEnabled(true);
        else menu.getItem(2).setEnabled(false);
        return true;
    }
}
